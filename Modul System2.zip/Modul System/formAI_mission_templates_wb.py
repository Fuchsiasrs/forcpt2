# Formations AI by Motomataru
# rel. 08/31/2012

# This function attaches AI_triggers only to missions "lead_charge" and "quick_battle_battle"
# For other missions, add to end of triggers list like so: " ] + AI_triggers "

# Make sure to comment out competing AI triggers in the mission templates modified
# But NOT morale scripts
# For example, for Warband 1.131 "lead_charge"

      # #AI Triggers
      # (0, 0, ti_once, [
          # (store_mission_timer_a,":mission_time"),(ge,":mission_time",2),
          # ],
       # [(call_script, "script_select_battle_tactic"),
        # (call_script, "script_battle_tactic_init"),
        # #(call_script, "script_battle_calculate_initial_powers"), #deciding run away method changed and that line is erased
        # ]),
      
# DON'T comment out morale/courage scripts that are HERE (between the AI triggers)...

      # (5, 0, 0, [
          # (store_mission_timer_a,":mission_time"),

          # (ge,":mission_time",3),
          
          # (call_script, "script_battle_tactic_apply"),
          # ], []), #applying battle tactic

from header_common import *
from header_operations import *
from module_constants import *
from header_mission_templates import *

#AI triggers v3 for WB by motomataru
AI_triggers = [  
	(ti_before_mission_start, 0, 0, [], [
		(assign, "$ranged_clock", 0),
		(assign, "$battle_phase", BP_Setup),
		(assign, "$clock_reset", 0),
		(init_position, Team0_Cavalry_Destination),
		(init_position, Team1_Cavalry_Destination),
		(init_position, Team2_Cavalry_Destination),
		(init_position, Team3_Cavalry_Destination),
	]),

	(0, 0, ti_once, [(gt, "$last_player_trigger", -2)], [	#delay 'til AFTER Formations trigger fires
		(try_for_agents, ":cur_agent"),
			(agent_set_slot, ":cur_agent",  slot_agent_is_running_away, 0),
		(try_end),
		(set_fixed_point_multiplier, 100),
		# (call_script, "script_store_battlegroup_data"),	done in formations trigger
		(try_for_range, ":team", 0, 4),
			(call_script, "script_battlegroup_get_position", pos0, ":team", grc_everyone),
			(position_get_x, reg0, pos0),
			(team_set_slot, ":team", slot_team_starting_x, reg0),
			(position_get_y, reg0, pos0),
			(team_set_slot, ":team", slot_team_starting_y, reg0),
			
			#prevent confusion over AI not using formations for archers
			(neq, ":team", "$fplayer_team_no"),
			(store_add, ":slot", slot_team_d0_formation, grc_archers),
			(team_set_slot, ":team", ":slot", formation_none),
		(try_end),
		(call_script, "script_field_tactics", 1)
	]),

	(.1, 0, 0, [(gt, "$last_player_trigger", 0)], [
		(store_mission_timer_c_msec, reg0),
		(val_sub, reg0, "$last_player_trigger"),
		(ge, reg0, 250),	#delay to offset from formations trigger (trigger delay does not work right)
		(val_add, "$last_player_trigger", 500),
		
		(try_begin),	#catch moment fighting starts
			(eq, "$clock_reset", 0),
			(call_script, "script_cf_any_fighting"),
			(call_script, "script_cf_count_casualties"),
			(assign, "$battle_phase", BP_Fight),
		(try_end),
		
		(set_fixed_point_multiplier, 100),
		(call_script, "script_store_battlegroup_data"),
		
		(try_begin),	#reassess ranged position when fighting starts
			(ge, "$battle_phase", BP_Fight),	#we have to do it this way because BP_Fight may be set in ways other than casualties
			(eq, "$clock_reset", 0),
			(call_script, "script_field_tactics", 1),
			(assign, "$ranged_clock", 0),
			(assign, "$clock_reset", 1),
			
		(else_try),	#at longer intervals after setup...
			(ge, "$battle_phase", BP_Jockey),
			# (store_mul, ":five_sec_modulus", 5, Reform_Trigger_Modulus),	#MOTO uncomment this section if archers too fidgety
			# (val_div, ":five_sec_modulus", formation_reform_interval),
			# (store_mod, reg0, "$ranged_clock", ":five_sec_modulus"),
			# (eq, reg0, 0),
			
			#reassess archer position
			(call_script, "script_field_tactics", 1),
			
			#catch reinforcements and set divisions to be retyped with new troops
			(try_begin),
				(neg|team_slot_eq, 0, slot_team_reinforcement_stage, "$defender_reinforcement_stage"),
				(team_set_slot, 0, slot_team_reinforcement_stage, "$defender_reinforcement_stage"),	
				(try_for_range, ":division", 0, 9),
					(store_add, ":slot", slot_team_d0_type, ":division"),
					(team_set_slot, 0, ":slot", sdt_unknown),
					(team_set_slot, 2, ":slot", sdt_unknown),
				(try_end),
			(try_end),
			(try_begin),
				(neg|team_slot_eq, 1, slot_team_reinforcement_stage, "$attacker_reinforcement_stage"),
				(team_set_slot, 1, slot_team_reinforcement_stage, "$attacker_reinforcement_stage"),	
				(try_for_range, ":division", 0, 9),
					(store_add, ":slot", slot_team_d0_type, ":division"),
					(team_set_slot, 1, ":slot", sdt_unknown),
					(team_set_slot, 3, ":slot", sdt_unknown),
				(try_end),
			(try_end),
			
		(else_try),
			(call_script, "script_field_tactics", 0),
		(try_end),
		
		(try_begin),
			(eq, "$battle_phase", BP_Setup),
			(assign, ":not_in_setup_position", 0),
			(try_for_range, ":bgteam", 0, 4),
				(neq, ":bgteam", "$fplayer_team_no"),
				(team_slot_ge, ":bgteam", slot_team_size, 1),
				(call_script, "script_battlegroup_get_position", pos1, ":bgteam", grc_archers),
				(team_get_order_position, pos0, ":bgteam", grc_archers),
				(get_distance_between_positions, reg0, pos0, pos1),
				(gt, reg0, 500),
				(assign, ":not_in_setup_position", 1),
			(try_end),
			(eq, ":not_in_setup_position", 0),	#all AI reached setup position?
			(assign, "$battle_phase", BP_Jockey),
		(try_end),
		
		(val_add, "$ranged_clock", 1),
	]),

	(0, 0, ti_once, [
		(main_hero_fallen),	#if AI to take over for mods with post-player battle action
		(eq, AI_Replace_Dead_Player, 1),
	], [
		(try_for_agents, ":agent"),	#reassign agents to the divisions AI uses
			(agent_is_alive, ":agent"),
			(call_script, "script_agent_fix_division", ":agent"),
		(try_end),

		(set_show_messages, 0),	#undo special player commands for divisions AI uses
		(try_for_range, ":division", 0, 3),
			(team_give_order, "$fplayer_team_no", ":division", mordr_use_any_weapon),
			(team_give_order, "$fplayer_team_no", ":division", mordr_fire_at_will),
		(try_end),
		(set_show_messages, 1),
	]),
]

def modmerge_formAI_mission_templates(orig_mission_templates):
	find_i = find_object( orig_mission_templates, "lead_charge" )
	orig_mission_templates[find_i][5].extend(AI_triggers)
	find_i = find_object( orig_mission_templates, "quick_battle_battle" )
	orig_mission_templates[find_i][5].extend(AI_triggers)
